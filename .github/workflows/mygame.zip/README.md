# Cover Game

Juego de pantalla LCD estilo handheld de los años 80. Código propio.

Dos calles con dos huecos cada una (4 en total) y una sola tapa. Los peatones cruzan; si pisan un hueco abierto, caen. Tres fallos y se acaba la partida. Al llegar a 200 y a 500 puntos se borran los fallos.

## Controles
- 4 botones rojos: cada uno mueve la tapa a un hueco (↖ ↗ calle de arriba, ↙ ↘ calle de abajo).
- Teclado: Q/P arriba, A/L abajo.
- GAME A / GAME B: dos velocidades (B: más peatones y más rápido). TIME: reloj.
- ALARM: ajusta la alarma con los 4 botones (↖ hora+, ↙ hora-, ↗ min+, ↘ min-); pulsa ALARM otra vez para activarla o apagarla.

## Obtener el APK
1. Sube este proyecto a un repositorio de GitHub.
2. Ve a la pestaña **Actions** > **Build APK** > **Run workflow** (también se ejecuta solo al hacer push).
3. Cuando termine, abre la ejecución y descarga el artefacto **covergame-apk**.
4. Descomprime el zip e instala `app-debug.apk` en el móvil (permite instalar de orígenes desconocidos).

El juego vive en `app/src/main/assets/index.html`. También se puede abrir en cualquier navegador.
